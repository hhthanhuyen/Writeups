Crack that hashed to plaintext. The base64 of the plaintext is the password to open the zip file.
