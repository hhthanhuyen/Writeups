from Crypto.Util.number import getStrongPrime
from random import getrandbits
from flag import FLAG
from os import urandom


class RSA:
    def __init__(self, p, q, e=65537):
        self.N = p*q
        self.e = e
        self.p = p
        self.q = q
        self.dp = pow(e, -1, p-1)
        self.dq = pow(e, -1, q-1)
        self.inv_q = pow(q, -1, p)

    def encrypt(self, m):
        return pow(m, self.e, self.N)

    def sign(self, m):
        Sp = pow(m, self.dp, self.p) if getrandbits(1) else pow(m, self.dp, self.p) | getrandbits(32)
        Sq = pow(m, self.dq, self.q) if getrandbits(1) else pow(m, self.dq, self.q) | getrandbits(32)
        S = Sq + self.q * (((Sp - Sq)*self.inv_q) % self.p)
        return S


if __name__ == "__main__":
    p = getStrongPrime(1024, e=65537)
    q = getStrongPrime(1024, e=65537)
    rsa = RSA(p, q)
    FLAG = int.from_bytes(urandom(245 - len(FLAG)) + FLAG, "big")
    for i in range(32):
        try:
            m = int(input("m: "))
            assert 1 < m < p*q
            print(rsa.sign(m))
        except:
            exit("Invalid input.")
    print(f"Encrypted flag: {rsa.encrypt(FLAG)}")
