from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from os import urandom
from flag import FLAG


def xor(x,y):
        return bytes([a^b for a,b in zip(x,y)])

class Challenge:
    def __init__(self, key):
        self.key = key
        self.message = b"Hi, I'm here for the flag, plz give it to me."
        self.cipher = AES.new(self.key, AES.MODE_ECB)

    def encrypt(self, plaintext):
        plaintext = bytes(16) + pad(plaintext, 16)
        ciphertext = urandom(16) # IV
        for i in range(16,len(plaintext),16):
            tmp = xor(xor(plaintext[i:i+16], plaintext[i-16:i]), ciphertext[i-16:i])
            tmp = self.cipher.encrypt(tmp)
            ciphertext += tmp
        return ciphertext
    
    def decrypt(self, ciphertext):
        plaintext = bytes(16)
        for i in range(16,len(ciphertext),16):
            tmp = self.cipher.decrypt(ciphertext[i:i+16])
            plaintext += xor(xor(tmp, plaintext[i-16:i]), ciphertext[i-16:i])
        plaintext = plaintext[16:]

        try:
            plaintext = unpad(plaintext,16)
            if plaintext == self.message:
                return FLAG
            else:
                return "Try again."
        except Exception as e:
            return e

if __name__ == "__main__":
    chall = Challenge(urandom(16))
    while True:
        try:
            ciphertext = bytes.fromhex(input())
            assert len(ciphertext) % 16 == 0 and len(ciphertext) >= 32
            print(chall.decrypt(ciphertext))
        except:
            break